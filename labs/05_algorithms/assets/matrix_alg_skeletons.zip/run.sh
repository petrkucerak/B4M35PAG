mpiexec -np 4 cmake/cmake-build-debug/Gauss_Elimination_Block
mpiexec -np 4 cmake/cmake-build-debug/Gauss_Elimination_Cyclic