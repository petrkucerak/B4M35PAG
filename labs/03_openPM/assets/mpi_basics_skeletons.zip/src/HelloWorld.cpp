#include <iostream>
#include <mpi.h>

using namespace std;

int main(int argc, char** argv) {
    cout << "How many processes running and what is my rank?:" << endl;

}
